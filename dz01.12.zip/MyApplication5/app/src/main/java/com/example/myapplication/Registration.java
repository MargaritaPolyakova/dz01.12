package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;

public class Registration extends AppCompatActivity {
    Intent intent;
    Button button;
    EditText surname , name, patronymic , date , school;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        surname = findViewById(R.id.surname);
        name = findViewById(R.id.name);
        patronymic = findViewById(R.id.patronymic);
        date = findViewById(R.id.date);
        school = findViewById(R.id.school);
        button = findViewById(R.id.button2);

        final Intent intent1 = new Intent(Registration.this,Anketa.class);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sur = String.valueOf(surname.getText());
                String nam = String.valueOf(name.getText());
                String sch = String.valueOf(school.getText());
                String dat = String.valueOf(date.getText());
                intent1.putExtra(Anketa.SUR, sur);
                intent1.putExtra(Anketa.NAM, nam);
                intent1.putExtra(Anketa.SCH, sch);
                intent1.putExtra(Anketa.AGE, dat);
                startActivity(intent1);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()){
            case R.id.about_item:
                Animation animation = AnimationUtils.loadAnimation(this,R.anim.animation);
                intent = new Intent(Registration.this, about.class);
                startActivity(intent);
                break;
            case R.id.close_item:
                Registration.this.finish();
                break;
        }
        return true;
    }
}
package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText login;
    EditText password;
    Button enter,button2;
    TextView rezult,rezult1;
    Intent intent;
    String L, P;
    boolean a;
    public static final String log = "Логин";
    public static final String pas = "Пароль";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = findViewById(R.id.login);
        password = findViewById(R.id.password);
        enter = findViewById(R.id.enter);
        rezult = findViewById(R.id.rezult);
        rezult1 = findViewById(R.id.rezult1);
        button2 = findViewById(R.id.button2);


        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rezult1.setText("");
                rezult.setText("");
                String logA = login.getText().toString();
                String pasA = password.getText().toString();
                if (logA.equals("") || pasA.equals("")) {
                    rezult.setText("Вы ничего не ввели");
                } else {
                    if (logA.equals(log) && pasA.equals(pas)) {
                        rezult1.setText("Верно");
                    } else rezult.setText("Вы ошиблись в логине или пароле");
                }
                login.setText("");
                password.setText("");

            }
        });
    }

    public void OnClick (View Button){
        switch (button2.getId()) {
            case R.id.button2:
                Animation animation = AnimationUtils.loadAnimation(this, R.anim.animation);
                intent = new Intent(MainActivity.this, Registration.class);
                startActivity(intent);
                break;
        }
    }
}
package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class Anketa extends AppCompatActivity {
    public static final String NAM = "key";
    public static final String SUR = "ley";
    public static final String AGE = "sey";
    public static final String SCH = "mey";

    TextView surname, name, age , school;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anketa);

        school =findViewById(R.id.school);
        surname =findViewById(R.id.surname);
        age =findViewById(R.id.age);
        name =findViewById(R.id.name);

        String getNa= String.valueOf(getIntent().getIntExtra(NAM,0));
        name.setText(getNa);

        String getSu= String.valueOf(getIntent().getIntExtra(SUR,0));
        surname.setText(getSu);

        String getAg= String.valueOf(getIntent().getIntExtra(AGE,0));
        age.setText(getAg);

        String getSc= String.valueOf(getIntent().getIntExtra(SCH,0));
        school.setText(getSc);

    }
}